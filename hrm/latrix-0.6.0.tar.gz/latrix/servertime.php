<meta http-equiv="Content-Type" content="text/xml; charset=UTF-8">
<meta http-equiv="Cache-Control" content="no-cache">
<?php echo date('H:i:s'); ?>