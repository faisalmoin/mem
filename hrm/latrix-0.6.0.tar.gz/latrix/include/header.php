<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<?php
	print '<title>'.la_version.$pagetitle.'</title>';
?>
	<meta name="generator" content="Bluefish 1.0.7">
	<meta name="author" content="Wolfgang Schulze-Zachau">
	<meta name="copyright" content="Manticore Software">
 	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8">
	<meta http-equiv="Content-Style-Type" content="text/css">
	<meta name="document-state" content="dynamic">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<link href="include/styles.css" type="text/css" rel="stylesheet">
	<link href="include/admin-styles.css" type="text/css" rel="stylesheet">
</head>
