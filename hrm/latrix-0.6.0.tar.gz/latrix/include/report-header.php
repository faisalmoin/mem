<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>LATRIX V%SHORTVERSION% :: Reports :: %TITLE%</title>
<meta name="generator" content="Bluefish 1.0.7">
<meta name="author" content="Wolfgang Schulze-Zachau">
<meta name="copyright" content="Manticore Software">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<LINK href="../include/styles.css" type="text/css" rel="stylesheet">
</head>
<body>
<table class=reporttable style="width: 100%;">
<tr>
	<td>
		<table style="width: 100%; padding: 0px; margin: 0px;" cellspacing="0px" cellpadding="0px">
			<tr>
				<td class="td-left">&nbsp;</td>
				<td class="td-left">LATRIX<br>Attendance Tracker V%SHORTVERSION%</td>
				<td >&nbsp;</td>
				<td >&nbsp;<h1>%TITLE%</h1>&nbsp;</td>
				<td >&nbsp;</td>
				<td class="td-right">%USERINFO%</td>
			</tr>		
		</table>
	</td>
</tr>
<tr>
	<td>
