<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>LATIMER V0.1 :: Reports :: Employee ID cards</title>
<meta name="generator" content="Bluefish 1.0.7">
<meta name="author" content="Wolfgang Schulze-Zachau">
<meta name="copyright" content="Manticore Software">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=UTF-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<STYLE type="text/css">
	table.maintable { font-family: arial, helvetica, sans-serif; text-align: center; }
   div.cardframe { border-width: 2px; border-style: solid; border-color: black; }
   p.note { font-size: 8pt; }
   p.emp-name { font-size: 14pt; font-weight: bold; }
   p.dep-name { font-size: 10pt; }
	p.key-code { font-size: 72pt; font-family: Code39-Digits, Broadway; }
 </STYLE>
</head>
<body>
<table class=maintable style="width: 100%;">
