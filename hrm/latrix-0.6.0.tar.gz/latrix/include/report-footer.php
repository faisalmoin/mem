<table style="width: 100%;">
	<tr>
		<td colspan=3>
		%ERROR%
		</td>
	</tr>
	<tr>
		<td style="width: 20%;"></td>
		<td style="text-align:center; width: 60%;">
			<hr class="ruler">
			<a href="http://www.manticore-uk.com">
				<img src="../images/manlogo.jpg" WIDTH="100" HEIGHT="64" alt="Manticore Software"></a><br>
			<span style="font-size:8pt">
			LATRIX Attendance Recording powered by Manticore Software<br>
			This page took	%LOADTIME% seconds to build.<br>
			Version %SHORTVERSION% Copyright &copy; 2006,2007 Manticore Software
			</span>
			</td>
		<td style="width: 20%;"></td>
	</tr>
</table>
</table>
</body>
</html>
