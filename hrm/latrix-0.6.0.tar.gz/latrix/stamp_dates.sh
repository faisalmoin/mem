cd /var/www/latrix
php5 stamp_dates.php
php5 add_date.php
php5 leave_headsup.php
