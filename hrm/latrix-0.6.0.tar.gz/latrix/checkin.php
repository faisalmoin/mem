<?php 
$page_title = 'checkin';
$help_url = 'http://www.latrix.org.uk/node/50';
require_once('timerecorder.php');

?>